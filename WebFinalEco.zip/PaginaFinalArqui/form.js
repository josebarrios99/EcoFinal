
  var firebaseConfig = {
    apiKey: "AIzaSyC5CW_ycWHhN-HgLO_7NT9Q16msukwt740",
    authDomain: "finalecojaa.firebaseapp.com",
    databaseURL: "https://finalecojaa.firebaseio.com",
    projectId: "finalecojaa",
    storageBucket: "finalecojaa.appspot.com",
    messagingSenderId: "504936441085",
    appId: "1:504936441085:web:3dcc44367a5f17e5bbca94"
  };
  firebase.initializeApp(firebaseConfig);

    const auth = firebase.auth();

    function signUp(){
        var email = document.getElementById("email");
        var password = document.getElementById("password");

        const promise = auth.createUserWithEmailAndPassword(email.value, password.value);
        promise.catch(e => alert(e.message));

        alert("Registrado");
        
    }
    function signIn(){
        var email = document.getElementById("text");
        var password = document.getElementById("password");

        const promise = auth.signInWithEmailAndPassword(email.value, password.value);
        promise.catch(e => alert(e.message));

        alert("Logueado" + text.value);
    }
    function signOut(){
        auth.signOut();
        alert("Cerraste sesion");
    }